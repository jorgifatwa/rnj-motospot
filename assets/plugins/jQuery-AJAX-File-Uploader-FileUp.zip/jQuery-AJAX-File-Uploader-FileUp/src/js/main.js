
import fileUp from "./fileup";

import "./lang/en";
import "./lang/ru";
import "./lang/es";
import "./lang/pt";

export default fileUp;